package edu.byuh.cis.cs203.tokens2.logic;

import java.util.ArrayList;
import java.util.List;

import android.os.Handler;
import android.os.Message;

public class Timer extends Handler {
	
	private List<TickListener> observers;
	private boolean paused;
	
	public Timer() {
		observers = new ArrayList<>();
		handleMessage(obtainMessage());
	}
	
	public void register(TickListener s) {
		observers.add(s);
	}
	
	public void deregister(TickListener s) {
		observers.remove(s);
	}

	public void setPaused() {
		paused = true;
	}

	public void unPause() {
		paused = false;
		handleMessage(obtainMessage());
	}

	@Override
	public void handleMessage(Message m) {
		for (TickListener s : observers) {
			s.onTick();
		}
		if(!paused){
			sendMessageDelayed(obtainMessage(), 100);

		}
	}
}

