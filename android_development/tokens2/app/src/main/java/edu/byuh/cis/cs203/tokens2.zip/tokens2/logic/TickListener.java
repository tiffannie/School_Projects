package edu.byuh.cis.cs203.tokens2.logic;

public interface TickListener {
	void onTick();
}
