package edu.byuh.cis.cs203.tokens2.logic;

/**
 * Created by tiffannie on 1/23/2017.
 */

public enum GameMode {
    ONE_PLAYER,
    TWO_PLAYER,
    //person will be player X, computer will be player O

}
