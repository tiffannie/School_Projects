package edu.byuh.cis.cs203.tokens2.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import edu.byuh.cis.cs203.tokens2.R;
import edu.byuh.cis.cs203.tokens2.logic.GameBoard;
import edu.byuh.cis.cs203.tokens2.logic.GameMode;
import edu.byuh.cis.cs203.tokens2.logic.Player;
import edu.byuh.cis.cs203.tokens2.logic.TickListener;
import edu.byuh.cis.cs203.tokens2.logic.Timer;

import static edu.byuh.cis.cs203.tokens2.logic.GameMode.ONE_PLAYER;
import static edu.byuh.cis.cs203.tokens2.logic.GameMode.TWO_PLAYER;

public class GameView extends View implements TickListener {

	private Grid grid;
	private boolean firstRun;
	private GuiButton currentButton;
	private GuiButton[] buttons;
	private List<GuiToken> tokens;
	private ArrayList<GuiToken> invisibleTokens = new ArrayList<>();
	private Map<Player, Bitmap> playerIcons;
	private GameBoard engine;
	private Timer timer;
	private int player0 = 0;
	private int playerX = 0;
	private Paint p;
	private GameMode gm;

	public GameView(Context context) {
		super(context);
		firstRun = true;
		buttons = new GuiButton[10];
		tokens = new ArrayList<GuiToken>();
		engine = GameBoard.Singleton();
		playerIcons = new HashMap<Player, Bitmap>();
		timer = new Timer();
		timer.register(this);
		p = new Paint();
		gm = ONE_PLAYER; //initialize not instantiate, tiff
	}
	
	@Override
	public void onDraw(Canvas c) {
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		p.setTextSize(90f);
		c.drawText("Pizza: " + String.valueOf(player0), getWidth()/3,getHeight()/9,p);
		c.drawText("Taco: " + String.valueOf(playerX), 2*getWidth()/3, getHeight()/9,p);

		if (firstRun) {
			init();
			firstRun = false;
		}

		grid.draw(c);
		
		for (GuiToken t : tokens) {
			t.draw(c);
			if(t.isInvisible(getHeight())) {
				timer.deregister(t); //unsubscribe
				invisibleTokens.add(t);//no concurrent modification error! booya!
			}
		}
		//remove tokens the have disappeared
		for(GuiToken dead : invisibleTokens){
			tokens.remove(dead);
		}
		for (GuiButton b : buttons) {
			b.draw(c);
		}
		

	}


	private void init() {
		AlertDialog.Builder b = new AlertDialog.Builder(getContext());
		AlertDialog dialog = b.setTitle("Welcome to Slide!")
				.setMessage("Player Mode:")
				.setPositiveButton("Single Player", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						gm = ONE_PLAYER;
					}
				})
				.setNegativeButton("Multi-Player", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						gm = TWO_PLAYER;
					}
				})
				.create();
		dialog.show();


		float w = getWidth();
		float h = getHeight();
		float unit = w/16f;
		float gridX = unit * 2.5f;
		float cellSize = unit * 2.3f;
		float gridY = unit * 9;
		float buttonTop = gridY - cellSize;
		float buttonLeft = gridX - cellSize;
		grid = new Grid(gridX, gridY, cellSize);
		buttons[0] = new GuiButton('1', this, buttonLeft + cellSize*1, buttonTop, cellSize);
		buttons[1] = new GuiButton('2', this, buttonLeft + cellSize*2, buttonTop, cellSize);
		buttons[2] = new GuiButton('3', this, buttonLeft + cellSize*3, buttonTop, cellSize);
		buttons[3] = new GuiButton('4', this, buttonLeft + cellSize*4, buttonTop, cellSize);
		buttons[4] = new GuiButton('5', this, buttonLeft + cellSize*5, buttonTop, cellSize);
		buttons[5] = new GuiButton('A', this, buttonLeft, buttonTop + cellSize*1, cellSize);
		buttons[6] = new GuiButton('B', this, buttonLeft, buttonTop + cellSize*2, cellSize);
		buttons[7] = new GuiButton('C', this, buttonLeft, buttonTop + cellSize*3, cellSize);
		buttons[8] = new GuiButton('D', this, buttonLeft, buttonTop + cellSize*4, cellSize);
		buttons[9] = new GuiButton('E', this, buttonLeft, buttonTop + cellSize*5, cellSize);
		Bitmap oImage = BitmapFactory.decodeResource(getResources(), R.drawable.taco);
		oImage = Bitmap.createScaledBitmap(oImage, (int)(cellSize),	(int)(cellSize), true);
		Bitmap xImage = BitmapFactory.decodeResource(getResources(), R.drawable.pizza);
		xImage = Bitmap.createScaledBitmap(xImage, (int)(cellSize),	(int)(cellSize), true);
		playerIcons.put(Player.X, xImage);
		playerIcons.put(Player.O, oImage);


	}

	@Override
	public boolean onTouchEvent(MotionEvent m) {

		//ignore touch events if the View is not fully initialized
		if (grid == null || firstRun) return true;
		
		//ignore touch events if there are any currently-moving tokens
		if (GuiToken.moving()) return true;
		
		float x = m.getX();
		float y = m.getY();
		if (m.getAction() == MotionEvent.ACTION_DOWN) {
			//Main.say("finger down!");
			currentButton = null;
			for (GuiButton b : buttons) {
				if (b.contains(x, y)) {
					currentButton = b;
					b.press();
					break;
				}
			}

			//show a helpful hint if the user taps inside the grid
			if (currentButton == null) {
				if (grid.contains(x, y)) {
					Toast t = Toast.makeText(getContext(),
							"To play, touch one of the buttons next to the grid.",
							Toast.LENGTH_LONG);
					t.setGravity(Gravity.TOP, 0, 0);
					t.show();
				}
			}

		} else if (m.getAction() == MotionEvent.ACTION_MOVE) {
			boolean touchingAButton = false;
			for (GuiButton b : buttons) {
				if (b.contains(x, y)) {
					touchingAButton = true;
					if (currentButton != null && b != currentButton) {
						currentButton.release();
						currentButton = null;
						break;
					}
				}
			}
			if (!touchingAButton) {
				unselectAllButtons();
			}
		} else if (m.getAction() == MotionEvent.ACTION_UP) {
			for (GuiButton b : buttons) {
				if (b.contains(x, y)) {
					if (b == currentButton) {
						currentButton.release();
						submitMove(currentButton);
					}
				}
			}
			currentButton = null;
		}
		invalidate();
		return true;
	}
	
	public void submitMove(GuiButton b) {
		char label = b.getLabel();
		Player p = engine.getCurrentPlayer();
		engine.submitMove(label, p);

		GuiToken newToken = new GuiToken(playerIcons.get(p), b.getBounds(), label);
		timer.register(newToken);

		List<GuiToken> neighbors = new ArrayList<>();
		neighbors.add(newToken);
		if (b.isTopButton()) {
			//we're moving down
			for (char row = 'A'; row <= 'E'; row++) {
				GuiToken tokenInColumn = getTokenAt(row, label);
				if (tokenInColumn != null) {
					neighbors.add(tokenInColumn);
				} else {
					break;
				}
			}
		}
		else {
			//we're moving right
			for (char col = '1'; col <= '5'; col++) {
				GuiToken tokenInRow = getTokenAt(label, col);
				if (tokenInRow != null) {
					neighbors.add(tokenInRow);
				} else {
					break;
				}
			}
		}
		tokens.add(newToken);

		
		//move them!
		if (b.isTopButton()) {
			for (GuiToken t : neighbors) {
				t.moveDown();
			}
		} else {
			for (GuiToken t : neighbors) {
				t.moveRight();
			}
		}
		

	}
	
	private GuiToken getTokenAt(char row, char col) {
		for (GuiToken gt : tokens) {
			if (gt.matches(row, col)) {
				return gt;
			}
		}
		return null;
	}

	private void unselectAllButtons() {
		for (GuiButton b : buttons) {
			b.release();
		}
	}
	private boolean checkMoving(){
		int count = 0;
		for(GuiToken g : tokens){
			if (!g.isMoving()){
				count++;
			}
		}
		if(count == tokens.size()){
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void onTick() {
		invalidate();
		if(checkMoving()) {
			if (engine.checkForWin() != Player.BLANK) {
				if (engine.checkForWin() != Player.TIE) {
					Player p = engine.getCurrentPlayer();
					if (engine.getCurrentPlayer() == Player.O) {
						player0++;
					} else {
						playerX++;
					}
					AlertDialog.Builder b = new AlertDialog.Builder(getContext());
					AlertDialog dialog = b.setTitle("We have a winner!")
							.setMessage("Player " + p.getText() + " got 5 in a row! Want to play again?")
							.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialogInterface, int i) {
									//reset the board
									init(); //runs all the code
									engine.clear();//clear this first!
									timer.unPause();
									//unsubscribing the tokens and clearing board
									for (GuiToken t : tokens) {
										timer.deregister(t);
										//Log.d("help", "I've been removed!");
									}
									tokens = new ArrayList<GuiToken>();
									invisibleTokens = new ArrayList<GuiToken>();
									invalidate();
								}
							})
							.setNegativeButton("No", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialogInterface, int i) {
									System.exit(i);
								}
							})
							.create();
					dialog.show();
					timer.setPaused();
				} else {
					player0++;
					playerX++;
					AlertDialog.Builder b = new AlertDialog.Builder(getContext());
					AlertDialog dialog = b.setTitle("Game Over!")
							.setMessage("It's a Tie! Want to play again?")
							.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialogInterface, int i) {
									init(); //runs all the code
									engine.clear();//clear this first!
									timer.unPause();
									for (GuiToken t : tokens) {
										timer.deregister(t);
										//Log.d("help", "I've been removed!");
									}
									tokens = new ArrayList<GuiToken>();
									invisibleTokens = new ArrayList<GuiToken>();
									invalidate();
								}
							})//put logic here!!!
							.setNegativeButton("No", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialogInterface, int i) {
									System.exit(i);
								}
							})
							.create();
					dialog.show();
					timer.setPaused();
				}
			} else {
				if (gm == ONE_PLAYER && engine.getCurrentPlayer() == Player.O && !GuiToken.moving()) {
					class randButton extends AsyncTask<Void, Void,GuiButton>{
						@Override
						protected GuiButton doInBackground(Void... args){
							int r = (int)(Math.random()*10);
							return buttons[r];
						}
						@Override
						protected void onPostExecute(GuiButton b) {
							submitMove(b);
						}
					} new randButton().execute();

				}
			}
		}
	}


}
