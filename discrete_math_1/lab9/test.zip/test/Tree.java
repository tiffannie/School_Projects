
import java.util.*; 

import javax.swing.*;

import java.awt.*;
import java.io.*;

public class Tree {


	//read in file
	public static void main(String args[]) {
		//storing each node to an array list
		ArrayList<Node> p = new ArrayList<>();
		ArrayList<ArrayList<Node>> line;
		Node root;
		Node left;
		Node right;
		line  = new ArrayList<>();
		//read in file
		String filename = (args[0]);
		//String filename = ("input.txt");
		File f = new File(filename); 
		try {
			//scan file in
			Scanner s = new Scanner(f);	
			while(s.hasNextLine()){
				ArrayList<Node> list = new ArrayList<>();				
				String a = s.nextLine();
				String[] b = a.split(", ");
				//for item in separated list of numbers

				for(String c : b) {					
					//convert the elements into objects
					Node n = new Node(Integer.parseInt(c));					
					//change type to integer
					list.add(n);
				}
				line.add(list);		//add the array list of objects to an array list
			}
			root = line.get(0).get(0);		//define root
			
			if(line.get(0).get(1) != null){
				left = line.get(0).get(1);		//define left child
				root.setLeft(left);
				root.getLeft().setParent(root);
			}

			if(line.get(0).get(2) !=null){
				right = line.get(0).get(2);		//define right child
				root.setRight(right);
				root.getRight().setParent(root);
			}

			for(ArrayList<Node> l : line){
				for(Node i : l){													//for node in array in array list of array lists
					if(i.getValue() == root.getLeft().getValue() && i != root.getLeft()){	//if value of node is same as root's left child and it's not already the child 
						int iLeft = l.indexOf(i)+1;									//set the node to the right of the node as it's left child
						root.getLeft().setLeft(l.get(iLeft));
						root.getLeft().getLeft().setParent(root.getLeft()); 
					}
					if(i.getValue()== root.getRight().getValue() && i != root.getRight()){		//do same for right child						
						int iRight = l.indexOf(i)+1;
						root.getRight().setRight(l.get(iRight));
						root.getRight().getRight().setParent(root.getRight());
					}
				}
			}
//			System.out.print(root.getLeft().getLeft().getParent());
		} catch (FileNotFoundException e) {
			System.out.println("Could not find " + filename);
		}
		root = line.get(0).get(0);		//defining the root
		preorder(line, root);			//calling the traversal methods
		inOrder(line, root);
		inOrder(line, root);
	}
	//defining the traversal methods
	public static void preorder(ArrayList<ArrayList<Node>> l, Node r){ //root left right
		System.out.println("Preorder");		
		System.out.println(r);
		r.checkLeft();			//refer to Node class for checkLeft/Right/InOrder methods
		r.checkRight();

	}
	
	public static void inOrder(ArrayList<ArrayList<Node>> l, Node r){ //left root right
		System.out.println("Inorder");
		r.checkInOrderLeft();
		System.out.println(r);
		r.checkInOrderRight();
	}
	public static void postorder(ArrayList<ArrayList<Node>> l, Node r) { //left right root
		System.out.println("Postorder");
		r.checkInOrderLeft();
		r.checkInOrderRight();
		System.out.println(r);
	}



}



