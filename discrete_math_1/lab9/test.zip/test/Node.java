
public class Node {
	
	private int value; //value/label of the node
	private Node left;
	private Node right;
	private Node parent = null;	
	
	//constructor
	Node(int input) { //every time that a new node is made or called, that is the new input
		value = input;//value is the current node
		left = null;
		right = null;
		parent = null;
		
	}
	
	//setter methods
	public void setLeft(Node a){
		left = a;		
	}
	
	public void setRight(Node b){
		right = b;		
	}
	
	public void setParent(Node n){
		parent = n;
	}	
	//getter methods
	public Node getLeft() {
		return left;
	}
	
	public Node getRight() {
		return right;
	}
	public int getValue(){
		return value;
	}
	public Node getParent(){
		return parent;
		
	}
	
	
	public void printNode() {
//		System.out.println(value);
//		System.out.println(left);
//		System.out.println(right);
	}
	
	//Methods
	public void checkRight(){				//if the current node has right child, print right child
		if(this.getRight()!= null){
			System.out.println(this.getRight());
			this.getRight().checkRight();		//recursive so it will do that for each node in line
		}
		
	}
	public void checkLeft(){		
		if(this.getLeft()!= null){				//same for left child
			System.out.println(this.getLeft());
			this.getLeft().checkLeft();			
		}
	}
	
	public void checkInOrderLeft(){			//current node is this
		Node n = this;
		if(this.getLeft()!= null){				//if node has left child
			this.getLeft().checkInOrderLeft();	//call the method within the method
			n = this.getLeft();					//redefine the node
		}else{
			this.checkParent(n);				//if not, call the check parent method on the node
		}		
	}
	
	public void checkInOrderRight(){
		Node n = this;
		if(this.getRight()!= null){
			this.getRight().checkInOrderRight();
			n = this.getRight();
		}else{
			this.checkParent(n);
		}		
	}
	
	public void checkParent(Node n){		
		Node r = n;
		if(n.getParent()!= null){			//if the node has a parent
			r = n.getParent();				//redefine the node as the parent of the current node
			System.out.println(n);			
			n.checkParent(r);				//will go through and redefine the rest of the node's parents
		}
	}
	@Override
	public String toString() {		//use to check value of the nodes. changes the location into string value
		return (Integer.toString(value));
	}
	@Override
	public boolean equals(Object o){
		if(o instanceof Node){
			Node other = (Node) o;
			return(this.getValue() == other.getValue());				
			}else{
				return false;
		}		
	}
}
