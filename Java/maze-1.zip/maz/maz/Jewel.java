package maz;
import javax.swing.ImageIcon;


public class Jewel extends Sprite {
		
	public Jewel() {
		super();//call superclass constructor
		image = new ImageIcon("Jewel.png");
	}
}