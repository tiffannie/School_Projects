package maz;
import javax.swing.ImageIcon;


public class Goliath extends Sprite {
		
	public Goliath() {
		super();//call superclass constructor
		image = new ImageIcon("goliath.png");
	}
}