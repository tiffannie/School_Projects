package maz;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.ImageIcon;


public abstract class Sprite 
				implements Drawable{
	
	protected Room currentRoom;//this is room where sprite will be drawn
	protected ImageIcon image;//picture that will be drawn for this sprite
	
	//default constructor. sprite doesn't have a room or an image
	public Sprite() {
		currentRoom = null;
		image = null;
	}
	
	//sets Room in which the sprite will appear
	public void setCurrentRoom(Room r) {
		currentRoom = r;
	}
	//getter method
	public Room getCurrentRoom() {
		return currentRoom;
	}
	
	//this method is responsible for drawing image inside parameter of Sprite's currentRoom
	@Override
	public void draw(Graphics g) {
		//image centered inside the room
		//check currentRoom and image are both non-null
		if(currentRoom != null){
			Point p = currentRoom.getPosition();
			image.paintIcon(null, g, p.x+15, p.y+10 );
		}
	}
	
	public void moveSouth() {
		if(currentRoom.hasSouthExit() == true){
			currentRoom = currentRoom.getSouthExit();
		}
	}
	
	public void moveNorth() {
		if(currentRoom.hasNorthExit() == true){
			currentRoom = currentRoom.getNorthExit();
		}
	}
	
	public void moveEast() {
		if(currentRoom.hasEastExit() == true){
			currentRoom = currentRoom.getEastExit();
		}
	}
	
	public void moveWest() {
		if(currentRoom.hasWestExit() == true){
			currentRoom = currentRoom.getWestExit();
		}
	}
	
}
 