package maz;
import javax.swing.ImageIcon;


public class David extends Sprite {
		
	private int numJewels; //will keep track of how many stones David is currently carrying
	
	public David() {
		
		super();//call superclass constructor
		image = new ImageIcon("david.png");
		
		numJewels = 0;
	}

	public void pickUpJewel() {
		numJewels ++;
	}
	public boolean isArmed() {
		if(numJewels == 5) {
			return true;
		}
		else {
			return false;
		}
	}
	public void reset() {
		numJewels = 0;
	}
}