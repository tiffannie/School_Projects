package maz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JApplet;
import javax.swing.JOptionPane;

/**
 * This is the "main" class of the program.
 * This is where all the other objects are created, and where
 * all the rendering (drawing) is initiated.
 *
 */
public class Maze extends JApplet 
        implements KeyListener {

	private ArrayList<Room> rooms;
	private ArrayList<Jewel> jewel;
	private ArrayList<Drawable> drawable;
	
	David david; 
	Goliath goliath;
	

	/**
	 * The init method runs once, at the very start of the program.
	 */
	@Override
	public void init() {
	    
	    addKeyListener(this);  

		david = new David();
		goliath = new Goliath();
		
		jewel = new ArrayList<Jewel>();	
		rooms = new ArrayList<Room>();
		drawable = new ArrayList<Drawable>();
		
		Room r0 = new Room(20000, 20000);
		Room r1 = new Room(10, 10);
		Room r2 = new Room(70, 10);
		Room r3 = new Room(130, 10);
		Room r4 = new Room(190, 10);
		Room r5 = new Room(10, 70);
		Room r6 = new Room(70, 70);
		Room r7 = new Room(130, 70);
		Room r8 = new Room(190, 70);
		Room r9 = new Room(10, 130);
		Room r10 = new Room(70, 130);
		Room r11 = new Room(130, 130);
		Room r12 = new Room(190, 130);
		Room r13 = new Room(10, 190);
		Room r14 = new Room(70, 190);
		Room r15 = new Room(130, 190);
		Room r16 = new Room(190, 190);

		rooms.add(r0);
		rooms.add(r1);
		rooms.add(r2);
		rooms.add(r3);
		rooms.add(r4);
		rooms.add(r5);
		rooms.add(r6);
		rooms.add(r7);
		rooms.add(r8);
		rooms.add(r9);
		rooms.add(r10);
		rooms.add(r11);
		rooms.add(r12);
		rooms.add(r13);
		rooms.add(r14);
		rooms.add(r15);
		rooms.add(r16);
		
		r1.setEastExit(r2);
		r2.setEastExit(r3);
		r2.setSouthExit(r6);
		r3.setEastExit(r4);
		r5.setEastExit(r6);
		r6.setEastExit(r7);
		r8.setSouthExit(r12);
		r9.setEastExit(r10);
		r9.setSouthExit(r13);
		r10.setEastExit(r11);
		r10.setNorthExit(r6);
		r11.setNorthExit(r7);
		r11.setSouthExit(r15);
		r12.setSouthExit(r16);
		r14.setEastExit(r15);
		r15.setEastExit(r16);
		
		david.setCurrentRoom(r1);
		goliath.setCurrentRoom(r15);
		
		//create new variables to put into jewel array
		Jewel j1 = new Jewel();
		Jewel j2 = new Jewel();
		Jewel j3 = new Jewel();
		Jewel j4 = new Jewel();
		Jewel j5 = new Jewel();
		
		//place jewels into array list
		jewel.add(j1);
		jewel.add(j2);
		jewel.add(j3);
		jewel.add(j4);
		jewel.add(j5);
		
		//set the room of the jewels
		j1.setCurrentRoom(r10);
		j2.setCurrentRoom(r5);
		j3.setCurrentRoom(r3);
		j4.setCurrentRoom(r13);
		j5.setCurrentRoom(r9);
		
		//add rooms to drawable
		//drawable.addAll(rooms);
		drawable.add(r1);
		drawable.add(r2);
		drawable.add(r3);
		drawable.add(r4);
		drawable.add(r5);
		drawable.add(r6);
		drawable.add(r7);
		drawable.add(r8);
		drawable.add(r9);
		drawable.add(r10);
		drawable.add(r11);
		drawable.add(r12);
		drawable.add(r13);
		drawable.add(r14);
		drawable.add(r15);
		drawable.add(r16);
		
		//add jewels to drawable
		drawable.add(j1);
		drawable.add(j2);
		drawable.add(j3);
		drawable.add(j4);
		drawable.add(j5);
		
		//add the boys
		drawable.add(david);
		drawable.add(goliath);
		
	}

	
	/**
	 * This method initiates all the drawing for the applet.
	 * Rather than drawing things directly, however, it delegates
	 * all the rendering to the individual Room/Sprite objects.
	 */
	@Override
	public void paint(Graphics g) {
        requestFocusInWindow();
		//fill in the background color
		g.setColor(new Color(255, 255, 255));
		g.fillRect(0, 0, getWidth(), getHeight());

		//draw the rooms 
//		for (int i=0; i<rooms.size(); i++) {
//			rooms.get(i).draw(g);
//		}
//		//draw the jewels
//		for(int j=0; j<jewel.size(); j++){
//			jewel.get(j).draw(g);
//		}
//		david.draw(g);
//		goliath.draw(g);
		
		for(Drawable d : drawable){
			d.draw(g);
		}
	}
    
	@Override
	public void keyPressed(KeyEvent e) {
			
		int k = e.getKeyCode();
		switch (k) {
			case KeyEvent.VK_UP:
			case KeyEvent.VK_NUMPAD8:
				david.moveNorth();
				break;
			case KeyEvent.VK_DOWN:
			case KeyEvent.VK_NUMPAD2:
				david.moveSouth();
				break;
			case KeyEvent.VK_RIGHT:
			case KeyEvent.VK_NUMPAD6:
				david.moveEast();
				break;
			case KeyEvent.VK_LEFT:
			case KeyEvent.VK_NUMPAD4:
				david.moveWest();
				break;
				
		//TO MAKE IT TWO PLAYER, GIVE GOLIATH HIS OWN KEYS
			case KeyEvent.VK_W:
				goliath.moveNorth();
				break;
			case KeyEvent.VK_X:
				goliath.moveSouth();
				break;
			case KeyEvent.VK_D:
				goliath.moveEast();
				break;
			case KeyEvent.VK_A:
				goliath.moveWest();
				break;
			default:
				System.out.println("unrecognized command, dawg.");
				break;
		}
		
		//for each stone object
		for(int j = 0; j < jewel.size() ; j++) {
			
			//if the stone's location is the same as David's
			if(jewel.get(j).getCurrentRoom() != null) {
				if(jewel.get(j).getCurrentRoom().equals(david.getCurrentRoom())) {
					//call pickUpJewel method to pick it up
					david.pickUpJewel(); 
					//set jewel's current room to null, so now there's nothing there
					jewel.get(j).setCurrentRoom(null);//it sees the room is null but it can't be null
				}
			}
		}
		
		//check if david's location is the same as Goliath's location
		if (david.getCurrentRoom().equals(goliath.getCurrentRoom())) {
			//check if David has five jewel ("is armed")
			if(david.isArmed()) {
				System.out.println("Congratulations David! You slew Goliath!");
				reset();
			}
			else {
				System.out.println("Oh no David! Goliath got you! Try again.");
				reset();
			}
		}
		
		//tells java to redraw the applet
		repaint();
	}
	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void keyTyped(KeyEvent e) {}//defines the key that is pressed

	//to reset the entire game
	private void reset() {
		//puts all sprites back to their starting locations
		jewel.get(0).setCurrentRoom(rooms.get(10));
		jewel.get(1).setCurrentRoom(rooms.get(5));
		jewel.get(2).setCurrentRoom(rooms.get(3));
		jewel.get(3).setCurrentRoom(rooms.get(13));
		jewel.get(4).setCurrentRoom(rooms.get(9));
		david.setCurrentRoom(rooms.get(1));
		goliath.setCurrentRoom(rooms.get(15));
		//reset david to be unarmed by calling reset method from david class
		david.reset();
		
	}
}
