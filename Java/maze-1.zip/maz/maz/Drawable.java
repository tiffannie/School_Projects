package maz;

import java.awt.Graphics;

public interface Drawable {
	
	abstract void draw(Graphics g);
}
