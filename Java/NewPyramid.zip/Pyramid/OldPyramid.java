import javax.swing.JApplet;

import java.awt.*;

public class OldPyramid extends JApplet {

	//new field of type Pyramid
	Pyramid one; //declared x as pyramid object
	Pyramid two;
	
	public void init(){
		Point p = new Point(40, 400);
		one = new Pyramid(90,300);
		two = new Pyramid(p);
	}
	
	@Override
	public void paint(Graphics g) {
		
		int w = getWidth();
		int h = getHeight();
		
		//draw sky
		g.setColor(new Color(117,197,224));
		g.fillRect(0, 0, w, h);
		
		//draw sun
		g.setColor(new Color(255,241,89));
		g.fillOval(50,50,75,75);
		
		//draw clouds overlapping, white grayish white
		g.setColor(Color.WHITE);
		g.fillOval(75,85,90,40);//first cloud
		g.fillOval(80,75,50,50);
		g.fillOval(90,70,50,50);
		g.fillOval(100,75,50,50);
		g.setColor(new Color(240,242,242));//middle gray cloud
		g.fillOval(115,98,90,40);
		g.fillOval(123,85,50,50);
		g.fillOval(130,80,50,50);
		g.fillOval(133,96,50,50);
		g.setColor(Color.WHITE);
		g.fillOval(135,85,90,40);//third cloud
		g.fillOval(142,75,50,50);
		g.fillOval(147,70,50,50);
		g.fillOval(160,75,50,50);

		
		//draw mountains
		g.setColor(new Color(31,105,37));
		g.fillRect(0, 250, w,h);//base of mountain
		g.fillOval(-20, 150, w,h);//peaks
		g.fillOval(75,175,w,h);
		g.fillOval(185,150,w,h);
		g.fillOval(280,125,w,h);
		
		//draw grass
		g.setColor(new Color(101,163,106));
		g.fillRect(0, 280, w, h);
		
		//draw airplane
		g.setColor(new Color(212, 201, 211));
		g.fillOval(260,50,15,40);//wings
		g.fillOval(277,55,10,30);//tail
		g.setColor(new Color(240, 218, 238));
		g.fillOval(240,62,50,15);//body
		g.setColor(new Color(0, 0, 0));
		g.fillOval(243,65,5,5);//windows
		g.fillOval(249,65,5,5);
		g.fillOval(256,65,5,5);
		
		//draw airplane sign
		g.setColor(new Color(222, 194, 151));
		g.fillRect(300,60,80,30);
		g.setColor(new Color(0, 0, 0));
		g.fillRect(285,70,15,1);
		g.drawString("Go Seasiders!", 300, 75);

//call draw method on pyramid object
		one.setStairColor(Color.RED);
		one.setBrickColor(Color.PINK);
		one.draw(g);  
		
		two.setStairColor(Color.BLUE);
		two.setBrickColor(Color.CYAN);
		two.draw(g);
	}

}