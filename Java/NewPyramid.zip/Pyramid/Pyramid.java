import java.awt.Color;
import java.awt.Graphics;

public class Pyramid { //constructor return types must be the same as class

    private Point pos; //where pyramid is drawn (in different class)
    private Color stairColor; //controls the pyramid's stair color
    private Color brickColor; //what color main brick color is

	public Pyramid() {//default constructor
	//put in colors for everything. 
		//point will be blank pos = 0,0
		pos = new Point(0, 0);
		stairColor = new Color(128, 101, 28);
		brickColor = new Color(237, 160, 43);
	}
	
	public Pyramid(int x, int y) {//sets position but colors and bricks are default.
	    this();//THIS CALLS THE PREVIOUS VARIABLES FROM FIRST CONSTRUCTOR
	    pos = new Point(x, y);
	}
	
	public Pyramid(Point p) {//sets position of pyramid to point p. stairs and bricks are set to default colors
	    //instead of x and y put p
		this();
		pos = new Point(p);
	}
	
	//**************methods********************
	
	public void setStairColor(Color c) {//stairs color passed in as c 
	    stairColor = c;
	}
	
	public void setBrickColor(Color c){//brick color passed in as c
	    brickColor = c;
	}
	
	public void draw(Graphics g) {//instructions to draw pyramid
	    
		int x = pos.x;
		int y = pos.y;
		//g.fillShape(x,y,width,height)
	    //draw Pyramid
		g.setColor(brickColor);
		g.fillRect(x,y, 200,40);//base
		g.fillRect(x+25,y-25,150,50);//middle
		g.fillRect(x+50,y-50,100,50);//top
		g.fillRect(x+75,y-75,60,50);//tippy top
		
		//stairs
		g.setColor(stairColor);
		g.fillRect(x+40,y+35,125,5);//bottom
		g.fillRect(x+50,y,100,5);//base
		g.fillRect(x+65,y-25,70,5);//middle
		g.fillRect(x+76,y-50,50,5);//top
		g.fillRect(x+90,y-75,25,5);//tippy top
		
	}
} 