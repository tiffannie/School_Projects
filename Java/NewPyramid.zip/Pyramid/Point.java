public class Point {
//writing recipe card
		int x;
		int y;
		
		public Point(int xx, int yy) {//constructor
			x = xx;
			y = yy;
		}
		public Point(){
			x = 0;
			y = 0;
		}
		
		public Point(Point p) {
			x = p.x; //making copy of other's coordinates
			y = p.y;
		}
}